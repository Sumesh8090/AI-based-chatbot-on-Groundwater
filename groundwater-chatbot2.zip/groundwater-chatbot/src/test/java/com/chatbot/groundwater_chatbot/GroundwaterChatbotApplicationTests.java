package com.chatbot.groundwater_chatbot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroundwaterChatbotApplicationTests {

	@Test
	void contextLoads() {
	}

}
