package com.chatbot.groundwater_chatbot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroundwaterChatbotApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroundwaterChatbotApplication.class, args);
	}

}
