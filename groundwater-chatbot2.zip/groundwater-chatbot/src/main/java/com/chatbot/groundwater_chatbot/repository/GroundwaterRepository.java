package com.chatbot.groundwater_chatbot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.chatbot.groundwater_chatbot.model.GroundwaterData;

public interface GroundwaterRepository extends JpaRepository<GroundwaterData, Long> {

}
