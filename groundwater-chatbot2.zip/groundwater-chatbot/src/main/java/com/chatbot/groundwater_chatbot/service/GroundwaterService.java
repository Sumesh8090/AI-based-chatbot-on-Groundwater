package com.chatbot.groundwater_chatbot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chatbot.groundwater_chatbot.model.GroundwaterData;
import com.chatbot.groundwater_chatbot.repository.GroundwaterRepository;

@Service
public class GroundwaterService {

	@Autowired
	private GroundwaterRepository repository;

	// Get all data
	public List<GroundwaterData> getAllData() {
		return repository.findAll();
	}

	// Save data
	public GroundwaterData saveData(GroundwaterData data) {
		return repository.save(data);
	}
}
