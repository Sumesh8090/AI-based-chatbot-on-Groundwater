package com.chatbot.groundwater_chatbot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.chatbot.groundwater_chatbot.model.GroundwaterData;
import com.chatbot.groundwater_chatbot.service.GroundwaterService;

@RestController
@RequestMapping("/api/groundwater")
@CrossOrigin
public class GroundwaterController {

	@Autowired
	private GroundwaterService service;

	// Get all data
	@GetMapping
	public List<GroundwaterData> getAll() {
		return service.getAllData();
	}

	// Save data
	@PostMapping
	public GroundwaterData addData(@RequestBody GroundwaterData data) {
		return service.saveData(data);
	}

	@GetMapping("/chat")
	public String chat(@RequestParam String message) {

		List<GroundwaterData> dataList = service.getAllData();
		message = message.trim().toLowerCase();

		// ->Database-based answers
		for (GroundwaterData data : dataList) {
			String location = data.getLocation().trim().toLowerCase();

			if (message.contains(location)) {

				if (message.contains("level")) {
					return "Water level in " + data.getLocation() + " is " + data.getWaterLevel();
				} else if (message.contains("quality")) {
					return "Water quality in " + data.getLocation() + " is " + data.getQuality();
				}

				else {
					return "In " + data.getLocation() + ", water level is " + data.getWaterLevel() + " and quality is "
							+ data.getQuality();

				}
			}
		}

		// -> General groundwater knowledge (AI-like responses)

		if (message.contains("groundwater resource assessment")) {
			return "Groundwater Resource Assessment evaluates the availability and sustainability of groundwater in a region based on recharge, extraction, and usage.";
		}

		if (message.contains("categorization")) {
			return "Areas are categorized as Safe, Semi-Critical, Critical, or Over-Exploited based on groundwater usage and recharge levels.";
		}

		if (message.contains("management")) {
			return "Groundwater management includes rainwater harvesting, recharge wells, controlled extraction, and sustainable usage practices.";
		}

		if (message.contains("noc")) {
			return "NOC (No Objection Certificate) is required for groundwater extraction. It is issued by authorities after checking usage and sustainability.";
		}

		if (message.contains("how to obtain noc")) {
			return "To obtain NOC, apply through the Central Ground Water Authority portal with required documents and usage details.";
		}

		if (message.contains("What is groundwater")) {
			return "Groundwater is water present beneath the Earth's surface in soil pore spaces and rock formations.";
		}

		if (message.contains("training")) {
			return "Training programs on groundwater are offered by government bodies like CGWB and environmental institutions.";
		}

		if (message.contains("report")) {
			return "Groundwater reports include water level data, quality analysis, recharge status, and management recommendations.";
		}

		return "Sorry, I couldn't understand your query. Please ask about groundwater, water level, quality, or NOC.";
	}
}
